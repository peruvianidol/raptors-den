MyAdvantage 4.0 by ttol
=======================

This is a production of The Tree of Life.

I will not be responsible if this program
sends off nuclear missles and bombs Iraq.
I will not be responsible if this program
misguides a Kennedy plane.
I will not be responsible if this program
gives sexual urges to presidents.
I will not be responsible if this program
makes your wall come alive with dancing witches.
I will not be responsible if this program
"accidentally" steals your $20 bill from your wallet.
I will not be responsible if this program
turns your computer into a toaster, and goes 'Ding!'.
I will not be responsible if this program
makes all your dreams come true -- then snatches it away.

Okay okay, here's the real disclaimer:
Use of this program warrents that you have read
through this whole document, and agree that all
actions taken with this program is with lawful
intent.  All consequences, actions, and results
of this program are that of the owners, and
The Tree of Life, his friends, his enemies,
and all other related parties will not be held
responsible.

Basically, I'm not going to get in trouble
just because you messed up.


New Features
============

- Green Bar all the time
- Go to configuration screen.  New options at the bottom.
- Loads of small stuff you can't see, but enhance the
  program.


Requirements
============

- Account at AllAdvantage.
  If you don't have one, start MyAdvantage.exe and click
  on 'Join'.


Get paid to Play Games (or Write Report, or Chat, etc)
======================================================

a.) Start the program up (after you've started up the
    View Bar).

b.) Click 'Get Paid to Compute', and then do whatever
    you want from then on.

note: All new windows will make the viewbar turn green
    within 30 seconds, but all current windows open
    will make the viewbar green immediately.
    For example, say my IRC client is open.  I click
    'Get Paid to Compute'.  Now I alt-tab back into
    my IRC client, and my viewbar is now green.
    Now, I open, say, My Documents (or notepad, or Word,
    or whatever), and my viewbar is
    red.  I wait up to 30 seconds, and the viewbar will
    be green.  Neeto!

Doube note: Using a IRC Client with a script that changes
    the topic continuously will cause this problem to
    not work on 'Get Paid to Compute' mode.  Either
    unload the script, or try to take out the topic-change
    part of the script.

What to do when you want to sleep
=================================

a.) Start the program up (after you've started up the
    View Bar) when you're about to go to sleep.

b.) Click 'Get paid to sleep', and make sure the titlebar
    says that you're getting paid.  If not, click it again
    until it says that.

c.) Make sure your browser starts up, and is focused.
    Now leave your computer and go to bed. When you
    wake up, click 'Stop'.  You may terminate the program
    if you like (by pressing the X button in the upper right
    corner).  If you can't get there because of
    my mouse movement thing, alt-tab to MyAdvantage and
    press Alt-F4.

d.) If you want to change where the program goes to, when
    it goes there, how long it stays there, etc., click
    on 'config MyAdvantage' on the main menu.

  i.   The X,Y coordinates on the left of the configuration
       screen are mouse coordinates.  To set your own,
       just move your mouse anywhere on the screen and press
       ctrl-shift-1.  That'll be the first one the program
       goes to.  To go set the second one, move mouse anywhere
       and press ctrl-shift-2.  Repeat process for three and four.

  ii.  The one in off to the middle-right is the URL's section.
       These are the ones that the program will go to while it
       it activated.  Just click on the text field of any of them,
       and change it to whatever you want.

  iii. On the very right is some fields with numbers.  These are
       delays.  These tell the program how long to wait before
       going on to the next URL.  Minimum value is 1.  Remember,
       these are in units of minutes.  Set them below 5 minutes,
       and you'll be fine.  Anywhere higher than 5, and you run
       the risk of AllAdvantage shutting off on you.

  iv.  Changes to the text fields are automagically saved.  No
       need for a 'save' button.  Once you change it, it is
       immediately written to the settings.ini.

Note:  Make sure Netscape/IE/[insert favorite browser here]
is focused.  It should be, because of my program, but just
double check anyways.  If it isn't, focus it with Alt-Tab.

Double Note:  Moving mouse over places will make 'instant
       help available.  Try it! :)

How to Reach
============
Come to #scenereview on Efnet or email ttol@stuph.org

Changes
=======

- v 4.0
  The Super-Ultimate Version.  Included ability to make the viewbar
  green all the time; added ability to create shortcuts in desktop
  as well as in start menu -> program files; and loads of other
  stuff.  
- v 3.0
  The Ultimate Version.  I added a configuration screen; added
  support for settings.ini; added 'hint' support; fixed version
  bug; support for variable delays; got rid of annoying mouse
  movement; implemented better anti-idle mouse movement; implemented
  customizable mouse X,Y coordinates with ctrl-shift-# keys; and
  a lot of other stuff.
- v 2.0
  Fixed a lot of stuff.  This one is suppose to work 100% because
  I made the mouse move and it sends stuff to windows to simulate
  a real user.  If this doesn't work, contact me immediately!
- v 1.1
  Reports that it doesn't work because it's focused on one site.
  Fixed.  Now cycles between several sites.
- v 1.0
  Initial release to the public